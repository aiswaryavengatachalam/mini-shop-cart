# Mini Shop – JavaScript Shopping Cart

## Chosen option
Small shop with a working cart.

## Features
- Product cards are rendered dynamically from a JavaScript array of objects.
- Add products to the cart and see the item count update.
- Remove an item; removing the final item correctly returns the cart to its empty state.
- Checkout preview modal shows item subtotals and the grand total.
- No card details or real payments are collected.

## How totals are calculated
Each product stores its price as a number. For each cart item:
`line total = numeric product price × quantity`
The grand total is the sum of all line totals. Prices are formatted as Indian rupees only when displayed.

## Run locally
Open `index.html` in a web browser.

## Publish a live link with GitHub Pages
1. Create a GitHub repository named `mini-shop-cart`.
2. Upload `index.html` and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select **main** and **/(root)**, then Save.
6. After GitHub publishes it, copy the Pages URL shown there. It will look like `https://YOUR-USERNAME.github.io/mini-shop-cart/`.
